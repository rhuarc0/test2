package com.mercuriy94.trl3lg.presentation.common.view;

/**
 * Created by nikita on 25.08.17.
 */

public interface IOnClickItemListener {

    void onClickItem(int position);
}
