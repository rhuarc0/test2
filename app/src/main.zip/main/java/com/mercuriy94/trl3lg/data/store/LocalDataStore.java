package com.mercuriy94.trl3lg.data.store;

import javax.inject.Inject;


public class LocalDataStore {

    @Inject
    public LocalDataStore() {
    }

}
