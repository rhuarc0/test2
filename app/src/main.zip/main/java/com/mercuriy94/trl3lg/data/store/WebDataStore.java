package com.mercuriy94.trl3lg.data.store;

import javax.inject.Inject;


/**
 * Created by nikita on 25.12.2016.
 */

public class WebDataStore {


    @Inject
    public WebDataStore(){

    }


}
