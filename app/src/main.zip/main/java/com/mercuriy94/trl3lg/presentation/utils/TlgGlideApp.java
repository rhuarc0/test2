package com.mercuriy94.trl3lg.presentation.utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by nikita on 18.08.17.
 */
@GlideModule
public class TlgGlideApp extends AppGlideModule {

}
