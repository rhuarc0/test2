package com.mercuriy94.trl3lg.data.repository.connection.rental.book.local;

/**
 * Created by nikita on 26.07.17.
 */

public interface IRentalBookLocalRepository {

}
