package com.mercuriy94.trl3lg.data.repository.connection.rental.book.local;

import javax.inject.Inject;

/**
 * Created by mercuriy94 on 27.07.17.
 */

public class RentalBookLocalRepository implements IRentalBookLocalRepository {


    @Inject
    public RentalBookLocalRepository() {
    }
}
