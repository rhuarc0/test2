package com.mercuriy94.trl3lg.presentation.common.router;

import android.content.Intent;

/**
 * Created by Nikita on 10.04.2017.
 */

public interface IRouterAdapter {

    void navigateTo(Intent intent);


    void finish();

}
